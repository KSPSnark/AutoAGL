# AutoAGL
Automatically switches altimeter between AGL and ASL as appropriate. Configurable settings.
